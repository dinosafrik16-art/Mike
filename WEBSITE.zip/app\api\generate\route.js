const OPENAI_URL = "https://api.openai.com/v1/responses";
const MODEL = "gpt-5";
const WEB_SEARCH_TOOL = { type: "web_search" };

export async function POST() {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return Response.json({
      error: "OPENAI_API_KEY is not configured",
      demo: true,
      topics: demoTopics(),
    }, { status: 200 });
  }

  const instructions = [
    "Ти контент-стратег і фактчекер для Dimio - SaaS управління орендою нерухомості в Україні.",
    "Зроби веб-пошук і запропонуй 4 теми на тиждень.",
    "Використовуй тільки твердження, які можна підтвердити джерелами.",
    "Для кожної теми дай мінімум 2 джерела з повними https URL.",
    "Не вигадуй статистику, закони, ціни, дати або назви компаній.",
    "Якщо факт не підтверджено джерелом, не використовуй його.",
    "Відповідай тільки валідним JSON без markdown."
  ].join("\n");

  const input = `Згенеруй 4 перевірені теми для Dimio на цей тиждень.
Аудиторія: орендодавці, орендарі, керуючі нерухомістю, власники 1-10+ об'єктів.
Напрями пошуку: ринок оренди України, PropTech, автоматизація платежів, документи оренди, OLX Нерухомість, DIM.RIA.

Формат:
{
  "topics": [
    {
      "id": "t1",
      "day": "Понеділок",
      "category": "news|tip|comparison|education|automation",
      "title": "до 70 символів",
      "hook": "короткий хук",
      "description": "опис теми",
      "content": "готовий текст поста 700-1000 символів",
      "claims": ["перевірений факт 1", "перевірений факт 2"],
      "sources": [
        {"title": "назва джерела", "url": "https://..."},
        {"title": "назва джерела", "url": "https://..."}
      ]
    }
  ]
}`;

  try {
    const data = await callOpenAI(apiKey, instructions, input);
    const text = extractText(data);
    const parsed = parseJson(text);
    const topics = normalizeTopics(parsed.topics || parsed);
    return Response.json({ topics, demo: false });
  } catch (error) {
    return Response.json({ error: error.message, topics: demoTopics(), demo: true }, { status: 200 });
  }
}

async function callOpenAI(apiKey, instructions, input) {
  const response = await fetch(OPENAI_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: MODEL,
      instructions,
      input,
      tools: [WEB_SEARCH_TOOL],
      tool_choice: "auto",
      include: ["web_search_call.action.sources"],
    }),
  });

  const data = await response.json();
  if (!response.ok || data.error) {
    throw new Error(data.error?.message || "OpenAI API request failed");
  }
  return data;
}

function extractText(data) {
  if (data.output_text) return data.output_text;

  return (data.output || [])
    .flatMap(item => item.content || [])
    .map(content => content.text || "")
    .join("\n");
}

function parseJson(raw) {
  const clean = String(raw || "").replace(/```json/g, "").replace(/```/g, "").trim();
  const match = clean.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
  return JSON.parse(match ? match[0] : clean);
}

function normalizeTopics(list) {
  if (!Array.isArray(list)) throw new Error("OpenAI returned invalid topics format");
  const days = ["Понеділок", "Вівторок", "Четвер", "П'ятниця"];
  return list.slice(0, 4).map((topic, index) => ({
    id: topic.id || `t${index + 1}`,
    day: topic.day || days[index],
    category: topic.category || "education",
    title: String(topic.title || "").slice(0, 90),
    hook: String(topic.hook || "").slice(0, 180),
    description: String(topic.description || "").slice(0, 260),
    content: String(topic.content || ""),
    claims: Array.isArray(topic.claims) ? topic.claims.slice(0, 6) : [],
    sources: Array.isArray(topic.sources) ? topic.sources.filter(s => s?.url).slice(0, 5) : [],
  })).filter(topic => topic.title);
}

function demoTopics() {
  return normalizeTopics([
    {
      id: "demo-1",
      day: "Понеділок",
      category: "demo",
      title: "Демо: підключи OpenAI API key для справжнього пошуку",
      hook: "Ця тема показує вигляд сайту, але не є перевіреною новиною.",
      description: "Додай OPENAI_API_KEY у Vercel, щоб сайт сам шукав правдиву інформацію.",
      content: "Демо-режим працює без ключа. Для реального веб-пошуку потрібен серверний OpenAI API key, який не видно користувачам.",
      claims: [],
      sources: []
    }
  ]);
}

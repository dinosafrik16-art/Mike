"use client";

import { useEffect, useMemo, useRef, useState } from "react";

const EMPTY_TOPIC = {
  id: "empty",
  day: "Понеділок",
  category: "empty",
  title: "Натисни кнопку, щоб згенерувати теми",
  hook: "Сайт сам зробить пошук, перевірить джерела і створить картинки.",
  description: "",
  content: "",
  claims: [],
  sources: [],
};

function isVerified(topic) {
  return (topic.sources || []).filter(source => /^https?:\/\//.test(source.url || "")).length >= 2
    && (topic.claims || []).length > 0;
}

function buildPayload(topic, squareImage, storyImage) {
  return {
    source: "dimio-best-website",
    sentAt: new Date().toISOString(),
    verified: isVerified(topic),
    topic,
    images: { squareImage, storyImage },
  };
}

export default function HomePage() {
  const [topics, setTopics] = useState([EMPTY_TOPIC]);
  const [selectedId, setSelectedId] = useState("empty");
  const [tab, setTab] = useState("content");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [webhook, setWebhook] = useState("");
  const squareRef = useRef(null);
  const storyRef = useRef(null);

  const selected = useMemo(
    () => topics.find(topic => topic.id === selectedId) || topics[0] || EMPTY_TOPIC,
    [topics, selectedId]
  );

  const verifiedCount = topics.filter(isVerified).length;

  useEffect(() => {
    setWebhook(localStorage.getItem("dimioBestWebhook") || "");
  }, []);

  useEffect(() => {
    drawImage(squareRef.current, selected, 1080, 1080);
    drawImage(storyRef.current, selected, 1080, 1350);
  }, [selected]);

  const generate = async () => {
    setLoading(true);
    setMessage("Шукаю правдиву інформацію і перевіряю джерела...");
    try {
      const response = await fetch("/api/generate", { method: "POST" });
      const data = await response.json();
      setTopics(data.topics?.length ? data.topics : [EMPTY_TOPIC]);
      setSelectedId(data.topics?.[0]?.id || "empty");
      setMessage(data.demo
        ? "Демо-режим: для реального пошуку додай OPENAI_API_KEY на хостингу."
        : "Готово: теми згенеровано і перевірено по джерелах.");
    } catch (error) {
      setMessage("Не вдалося згенерувати теми. Перевір підключення сайту.");
    } finally {
      setLoading(false);
    }
  };

  const saveWebhook = value => {
    setWebhook(value);
    localStorage.setItem("dimioBestWebhook", value);
  };

  const sendToMake = async all => {
    if (!webhook.trim()) {
      setMessage("Встав Make webhook URL.");
      return;
    }

    const square = squareRef.current?.toDataURL("image/png") || "";
    const story = storyRef.current?.toDataURL("image/png") || "";
    const items = all
      ? topics.map(topic => buildPayload(topic, square, story))
      : [buildPayload(selected, square, story)];

    await fetch(webhook, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items }),
    });
    setMessage("Відправлено в Make.");
  };

  const copyJson = async () => {
    await navigator.clipboard.writeText(JSON.stringify({ topics }, null, 2));
    setMessage("JSON скопійовано.");
  };

  const downloadPng = () => {
    const link = document.createElement("a");
    link.href = squareRef.current.toDataURL("image/png");
    link.download = "dimio-topic.png";
    link.click();
  };

  return (
    <main className="page">
      <header className="top">
        <div className="brand">
          <div className="logo">D</div>
          <div>
            <strong>Dimio Verified Planner</strong>
            <span>пошук, джерела, картинки, Make</span>
          </div>
        </div>
        <div className="topActions">
          <button onClick={generate} disabled={loading}>{loading ? "Шукаю..." : "Згенерувати теми"}</button>
          <button className="secondary" onClick={copyJson}>Копіювати JSON</button>
        </div>
      </header>

      <section className="hero">
        <div>
          <div className="eyebrow">Одна кнопка</div>
          <h1>Сайт сам генерує 4 перевірені теми для Dimio</h1>
          <p>Після підключення ключа на сервері користувач нічого не вводить: натискає кнопку, отримує теми з джерелами, PNG-картинки і може відправити все в Make.</p>
        </div>
        <div className="score">
          <strong>{verifiedCount}/{topics.length}</strong>
          <span>тем мають достатньо джерел</span>
        </div>
      </section>

      {message && <div className="notice">{message}</div>}

      <section className="answers">
        <div><strong>1. Правдивість</strong><p>Шукає через web search і вимагає мінімум 2 джерела.</p></div>
        <div><strong>2. Оплата</strong><p>Для автоматичного режиму потрібен API key на сервері.</p></div>
        <div><strong>3. Онлайн</strong><p>Працює на Vercel/сервері, не тільки на ноутбуці.</p></div>
        <div><strong>4. Логіка</strong><p>Кнопка → пошук → JSON → перевірка → PNG → Make.</p></div>
        <div><strong>5. Мова</strong><p>Next.js, React, HTML, CSS, JavaScript.</p></div>
      </section>

      <section className="grid">
        <aside className="panel">
          <div className="panelHead">
            <h2>Теми</h2>
            <span>{topics.length}</span>
          </div>
          <div className="topicList">
            {topics.map(topic => (
              <button
                key={topic.id}
                className={`topic ${topic.id === selected.id ? "active" : ""}`}
                onClick={() => setSelectedId(topic.id)}
              >
                <span className={isVerified(topic) ? "ok" : "warn"}>{isVerified(topic) ? "Перевірено" : "Не перевірено"}</span>
                <strong>{topic.title}</strong>
                <small>{topic.day} · {topic.category}</small>
              </button>
            ))}
          </div>
        </aside>

        <section className="panel mainPanel">
          <div className="selectedHead">
            <div>
              <span className={isVerified(selected) ? "badge ok" : "badge warn"}>{isVerified(selected) ? "Перевірено джерелами" : "Потрібні джерела"}</span>
              <h2>{selected.title}</h2>
              <p>{selected.hook}</p>
            </div>
            <button className="secondary" onClick={downloadPng}>Скачати PNG</button>
          </div>

          <div className="tabs">
            {["content", "sources", "claims", "make"].map(item => (
              <button key={item} className={tab === item ? "active" : ""} onClick={() => setTab(item)}>
                {item === "content" ? "Контент" : item === "sources" ? "Джерела" : item === "claims" ? "Факти" : "Make JSON"}
              </button>
            ))}
          </div>

          <pre>{renderTab(selected, tab)}</pre>

          {tab === "sources" && (
            <div className="sources">
              {(selected.sources || []).map((source, index) => (
                <a key={index} href={source.url} target="_blank" rel="noreferrer">{source.title || source.url}</a>
              ))}
            </div>
          )}

          <div className="canvasGrid">
            <canvas ref={squareRef} width="1080" height="1080" />
            <canvas ref={storyRef} width="1080" height="1350" />
          </div>

          <div className="make">
            <input value={webhook} onChange={event => saveWebhook(event.target.value)} placeholder="Make webhook URL" />
            <button className="green" onClick={() => sendToMake(false)}>В Make</button>
            <button className="secondary" onClick={() => sendToMake(true)}>Всі теми</button>
          </div>
        </section>
      </section>
    </main>
  );
}

function renderTab(topic, tab) {
  if (tab === "content") return topic.content || topic.description || "Контент ще не згенеровано.";
  if (tab === "claims") return (topic.claims || []).map((claim, index) => `${index + 1}. ${claim}`).join("\n") || "Факти не додано.";
  if (tab === "sources") return isVerified(topic) ? "Джерела є. Відкрий посилання нижче." : "Для перевірки потрібно мінімум 2 URL-джерела.";
  return JSON.stringify({ topic, verified: isVerified(topic) }, null, 2);
}

function drawImage(canvas, topic, width, height) {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  canvas.width = width;
  canvas.height = height;

  const verified = isVerified(topic);
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, "#07111f");
  gradient.addColorStop(1, verified ? "#123a34" : "#3a2b12");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  ctx.globalAlpha = 0.18;
  ctx.fillStyle = verified ? "#18b981" : "#f5b642";
  ctx.beginPath();
  ctx.arc(width - 110, 120, 340, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;

  ctx.fillStyle = verified ? "#18b981" : "#f5b642";
  roundRect(ctx, 70, 70, verified ? 250 : 290, 52, 26);
  ctx.fill();
  ctx.fillStyle = verified ? "#062016" : "#241704";
  ctx.font = "700 24px system-ui, sans-serif";
  ctx.fillText(verified ? "ПЕРЕВІРЕНО" : "ПОТРІБНІ ДЖЕРЕЛА", 92, 105);

  ctx.fillStyle = "#fff";
  ctx.font = "800 66px system-ui, sans-serif";
  wrapText(ctx, topic.title, 70, height * 0.36, width - 140, 78);

  ctx.fillStyle = "rgba(255,255,255,.72)";
  ctx.font = "34px system-ui, sans-serif";
  wrapText(ctx, topic.hook || topic.description || "", 70, height * 0.58, width - 140, 46);

  ctx.fillStyle = "rgba(255,255,255,.35)";
  ctx.fillRect(70, height - 150, width - 140, 1);
  ctx.fillStyle = "#fff";
  ctx.font = "800 30px system-ui, sans-serif";
  ctx.fillText("DIMIO", 70, height - 90);
  ctx.fillStyle = "rgba(255,255,255,.65)";
  ctx.font = "24px system-ui, sans-serif";
  ctx.fillText(`${topic.day} · ${topic.category}`, 180, height - 90);
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = String(text || "").split(/\s+/);
  let line = "";
  words.forEach((word, index) => {
    const test = line + word + " ";
    if (ctx.measureText(test).width > maxWidth && index > 0) {
      ctx.fillText(line, x, y);
      line = word + " ";
      y += lineHeight;
    } else {
      line = test;
    }
  });
  ctx.fillText(line, x, y);
}
